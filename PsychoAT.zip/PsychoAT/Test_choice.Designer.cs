﻿namespace PsychoAT
{
    partial class Test_choice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.WnName = new System.Windows.Forms.Label();
            this.test_choise_1 = new Guna.UI2.WinForms.Guna2Button();
            this.test_choise_2 = new Guna.UI2.WinForms.Guna2Button();
            this.test_choise_3 = new Guna.UI2.WinForms.Guna2Button();
            this.test_choise_4 = new Guna.UI2.WinForms.Guna2Button();
            this.test_choise_5 = new Guna.UI2.WinForms.Guna2Button();
            this.test_page_back = new Guna.UI2.WinForms.Guna2Button();
            this.test_page_next = new Guna.UI2.WinForms.Guna2Button();
            this.test_choise_back_to_menu = new Guna.UI2.WinForms.Guna2Button();
            this.TypeT1 = new System.Windows.Forms.Label();
            this.TypeT2 = new System.Windows.Forms.Label();
            this.TypeT3 = new System.Windows.Forms.Label();
            this.TypeT4 = new System.Windows.Forms.Label();
            this.TypeT5 = new System.Windows.Forms.Label();
            this.Author1 = new System.Windows.Forms.Label();
            this.Author2 = new System.Windows.Forms.Label();
            this.Author3 = new System.Windows.Forms.Label();
            this.Author4 = new System.Windows.Forms.Label();
            this.Author5 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 4.85243F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.17176F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.14529F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 21.87571F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.954804F));
            this.tableLayoutPanel1.Controls.Add(this.WnName, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.test_choise_1, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.test_choise_2, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.test_choise_3, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.test_choise_4, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.test_choise_5, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.test_page_back, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.test_page_next, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.test_choise_back_to_menu, 3, 9);
            this.tableLayoutPanel1.Controls.Add(this.TypeT1, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.TypeT2, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.TypeT3, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.TypeT4, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.TypeT5, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.Author1, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.Author2, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.Author3, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.Author4, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.Author5, 3, 6);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(-6, -27);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 10;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.174196F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.5026F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.92646F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.92646F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.92646F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.92646F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.85256F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2.776236F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.814395F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.174196F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(733, 591);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // WnName
            // 
            this.WnName.AutoSize = true;
            this.WnName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(173)))), ((int)(((byte)(193)))), ((int)(((byte)(120)))));
            this.WnName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.WnName.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.WnName.ForeColor = System.Drawing.Color.White;
            this.WnName.Location = new System.Drawing.Point(45, 64);
            this.WnName.Margin = new System.Windows.Forms.Padding(10);
            this.WnName.Name = "WnName";
            this.WnName.Size = new System.Drawing.Size(274, 59);
            this.WnName.TabIndex = 31;
            this.WnName.Text = "Выбор теста";
            this.WnName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // test_choise_1
            // 
            this.test_choise_1.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.test_choise_1.Animated = true;
            this.test_choise_1.BorderRadius = 10;
            this.test_choise_1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.test_choise_1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.test_choise_1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.test_choise_1.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.test_choise_1.ForeColor = System.Drawing.Color.White;
            this.test_choise_1.Location = new System.Drawing.Point(37, 140);
            this.test_choise_1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.test_choise_1.Name = "test_choise_1";
            this.test_choise_1.Size = new System.Drawing.Size(276, 55);
            this.test_choise_1.TabIndex = 18;
            this.test_choise_1.Text = "Тест1";
            this.test_choise_1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // test_choise_2
            // 
            this.test_choise_2.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.test_choise_2.Animated = true;
            this.test_choise_2.BorderRadius = 10;
            this.test_choise_2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.test_choise_2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.test_choise_2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.test_choise_2.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.test_choise_2.ForeColor = System.Drawing.Color.White;
            this.test_choise_2.Location = new System.Drawing.Point(37, 210);
            this.test_choise_2.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.test_choise_2.Name = "test_choise_2";
            this.test_choise_2.Size = new System.Drawing.Size(276, 55);
            this.test_choise_2.TabIndex = 19;
            this.test_choise_2.Text = "Тест1";
            this.test_choise_2.Click += new System.EventHandler(this.guna2Button2_Click);
            // 
            // test_choise_3
            // 
            this.test_choise_3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.test_choise_3.Animated = true;
            this.test_choise_3.BorderRadius = 10;
            this.test_choise_3.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_3.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_3.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.test_choise_3.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.test_choise_3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.test_choise_3.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.test_choise_3.ForeColor = System.Drawing.Color.White;
            this.test_choise_3.Location = new System.Drawing.Point(37, 280);
            this.test_choise_3.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.test_choise_3.Name = "test_choise_3";
            this.test_choise_3.Size = new System.Drawing.Size(276, 55);
            this.test_choise_3.TabIndex = 20;
            this.test_choise_3.Text = "Тест1";
            this.test_choise_3.Click += new System.EventHandler(this.test_choise_3_Click);
            // 
            // test_choise_4
            // 
            this.test_choise_4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.test_choise_4.Animated = true;
            this.test_choise_4.BorderRadius = 10;
            this.test_choise_4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.test_choise_4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.test_choise_4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.test_choise_4.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.test_choise_4.ForeColor = System.Drawing.Color.White;
            this.test_choise_4.Location = new System.Drawing.Point(37, 350);
            this.test_choise_4.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.test_choise_4.Name = "test_choise_4";
            this.test_choise_4.Size = new System.Drawing.Size(276, 55);
            this.test_choise_4.TabIndex = 21;
            this.test_choise_4.Text = "Тест1";
            this.test_choise_4.Click += new System.EventHandler(this.test_choise_4_Click);
            // 
            // test_choise_5
            // 
            this.test_choise_5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.test_choise_5.Animated = true;
            this.test_choise_5.BorderRadius = 10;
            this.test_choise_5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.test_choise_5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.test_choise_5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.test_choise_5.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.test_choise_5.ForeColor = System.Drawing.Color.White;
            this.test_choise_5.Location = new System.Drawing.Point(37, 417);
            this.test_choise_5.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.test_choise_5.Name = "test_choise_5";
            this.test_choise_5.Size = new System.Drawing.Size(276, 55);
            this.test_choise_5.TabIndex = 22;
            this.test_choise_5.Text = "Тест1";
            this.test_choise_5.Click += new System.EventHandler(this.test_choise_5_Click);
            // 
            // test_page_back
            // 
            this.test_page_back.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.test_page_back.Animated = true;
            this.test_page_back.BorderRadius = 10;
            this.test_page_back.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.test_page_back.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.test_page_back.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.test_page_back.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.test_page_back.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(88)))), ((int)(((byte)(76)))));
            this.test_page_back.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.test_page_back.ForeColor = System.Drawing.Color.White;
            this.test_page_back.Location = new System.Drawing.Point(37, 537);
            this.test_page_back.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.test_page_back.Name = "test_page_back";
            this.test_page_back.Size = new System.Drawing.Size(114, 49);
            this.test_page_back.TabIndex = 0;
            this.test_page_back.Text = "Назад";
            this.test_page_back.Click += new System.EventHandler(this.test_page_back_Click);
            // 
            // test_page_next
            // 
            this.test_page_next.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.test_page_next.Animated = true;
            this.test_page_next.BorderRadius = 10;
            this.test_page_next.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.test_page_next.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.test_page_next.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.test_page_next.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.test_page_next.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(108)))), ((int)(((byte)(88)))), ((int)(((byte)(76)))));
            this.test_page_next.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.test_page_next.ForeColor = System.Drawing.Color.White;
            this.test_page_next.Location = new System.Drawing.Point(397, 537);
            this.test_page_next.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.test_page_next.Name = "test_page_next";
            this.test_page_next.Size = new System.Drawing.Size(114, 49);
            this.test_page_next.TabIndex = 0;
            this.test_page_next.Text = "Вперед";
            this.test_page_next.Click += new System.EventHandler(this.test_page_next_Click);
            // 
            // test_choise_back_to_menu
            // 
            this.test_choise_back_to_menu.Animated = true;
            this.test_choise_back_to_menu.BorderRadius = 10;
            this.test_choise_back_to_menu.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_back_to_menu.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.test_choise_back_to_menu.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.test_choise_back_to_menu.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.test_choise_back_to_menu.Dock = System.Windows.Forms.DockStyle.Right;
            this.test_choise_back_to_menu.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(84)))), ((int)(((byte)(77)))));
            this.test_choise_back_to_menu.Font = new System.Drawing.Font("Cascadia Mono SemiBold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.test_choise_back_to_menu.ForeColor = System.Drawing.Color.White;
            this.test_choise_back_to_menu.Location = new System.Drawing.Point(548, 536);
            this.test_choise_back_to_menu.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.test_choise_back_to_menu.Name = "test_choise_back_to_menu";
            this.test_choise_back_to_menu.Size = new System.Drawing.Size(123, 52);
            this.test_choise_back_to_menu.TabIndex = 29;
            this.test_choise_back_to_menu.Text = "Выход";
            this.test_choise_back_to_menu.Click += new System.EventHandler(this.guna2Button19_Click);
            // 
            // TypeT1
            // 
            this.TypeT1.AutoSize = true;
            this.TypeT1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.TypeT1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TypeT1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TypeT1.ForeColor = System.Drawing.Color.White;
            this.TypeT1.Location = new System.Drawing.Point(336, 139);
            this.TypeT1.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TypeT1.Name = "TypeT1";
            this.TypeT1.Padding = new System.Windows.Forms.Padding(1);
            this.TypeT1.Size = new System.Drawing.Size(170, 58);
            this.TypeT1.TabIndex = 32;
            this.TypeT1.Text = "Неизвестный тип";
            this.TypeT1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.TypeT1.Click += new System.EventHandler(this.label2_Click);
            // 
            // TypeT2
            // 
            this.TypeT2.AutoSize = true;
            this.TypeT2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.TypeT2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TypeT2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TypeT2.ForeColor = System.Drawing.Color.White;
            this.TypeT2.Location = new System.Drawing.Point(336, 209);
            this.TypeT2.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TypeT2.Name = "TypeT2";
            this.TypeT2.Padding = new System.Windows.Forms.Padding(1);
            this.TypeT2.Size = new System.Drawing.Size(170, 58);
            this.TypeT2.TabIndex = 33;
            this.TypeT2.Text = "Неизвестный тип";
            this.TypeT2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TypeT3
            // 
            this.TypeT3.AutoSize = true;
            this.TypeT3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.TypeT3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TypeT3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TypeT3.ForeColor = System.Drawing.Color.White;
            this.TypeT3.Location = new System.Drawing.Point(336, 279);
            this.TypeT3.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TypeT3.Name = "TypeT3";
            this.TypeT3.Padding = new System.Windows.Forms.Padding(1);
            this.TypeT3.Size = new System.Drawing.Size(170, 58);
            this.TypeT3.TabIndex = 34;
            this.TypeT3.Text = "Неизвестный тип";
            this.TypeT3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TypeT4
            // 
            this.TypeT4.AutoSize = true;
            this.TypeT4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.TypeT4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TypeT4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TypeT4.ForeColor = System.Drawing.Color.White;
            this.TypeT4.Location = new System.Drawing.Point(336, 349);
            this.TypeT4.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TypeT4.Name = "TypeT4";
            this.TypeT4.Padding = new System.Windows.Forms.Padding(1);
            this.TypeT4.Size = new System.Drawing.Size(170, 58);
            this.TypeT4.TabIndex = 35;
            this.TypeT4.Text = "Неизвестный тип";
            this.TypeT4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TypeT5
            // 
            this.TypeT5.AutoSize = true;
            this.TypeT5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.TypeT5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TypeT5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TypeT5.ForeColor = System.Drawing.Color.White;
            this.TypeT5.Location = new System.Drawing.Point(336, 419);
            this.TypeT5.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.TypeT5.Name = "TypeT5";
            this.TypeT5.Padding = new System.Windows.Forms.Padding(1);
            this.TypeT5.Size = new System.Drawing.Size(170, 52);
            this.TypeT5.TabIndex = 36;
            this.TypeT5.Text = "Неизвестный тип";
            this.TypeT5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Author1
            // 
            this.Author1.AutoSize = true;
            this.Author1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.Author1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Author1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Author1.ForeColor = System.Drawing.Color.White;
            this.Author1.Location = new System.Drawing.Point(520, 139);
            this.Author1.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.Author1.Name = "Author1";
            this.Author1.Padding = new System.Windows.Forms.Padding(1);
            this.Author1.Size = new System.Drawing.Size(146, 58);
            this.Author1.TabIndex = 37;
            this.Author1.Text = "Неизвестный Автор";
            this.Author1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Author2
            // 
            this.Author2.AutoSize = true;
            this.Author2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.Author2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Author2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Author2.ForeColor = System.Drawing.Color.White;
            this.Author2.Location = new System.Drawing.Point(520, 209);
            this.Author2.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.Author2.Name = "Author2";
            this.Author2.Padding = new System.Windows.Forms.Padding(1);
            this.Author2.Size = new System.Drawing.Size(146, 58);
            this.Author2.TabIndex = 38;
            this.Author2.Text = "Неизвестный Автор";
            this.Author2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Author3
            // 
            this.Author3.AutoSize = true;
            this.Author3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.Author3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Author3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Author3.ForeColor = System.Drawing.Color.White;
            this.Author3.Location = new System.Drawing.Point(520, 279);
            this.Author3.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.Author3.Name = "Author3";
            this.Author3.Padding = new System.Windows.Forms.Padding(1);
            this.Author3.Size = new System.Drawing.Size(146, 58);
            this.Author3.TabIndex = 39;
            this.Author3.Text = "Неизвестный Автор";
            this.Author3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Author4
            // 
            this.Author4.AutoSize = true;
            this.Author4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.Author4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Author4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Author4.ForeColor = System.Drawing.Color.White;
            this.Author4.Location = new System.Drawing.Point(520, 349);
            this.Author4.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.Author4.Name = "Author4";
            this.Author4.Padding = new System.Windows.Forms.Padding(1);
            this.Author4.Size = new System.Drawing.Size(146, 58);
            this.Author4.TabIndex = 40;
            this.Author4.Text = "Неизвестный Автор";
            this.Author4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Author5
            // 
            this.Author5.AutoSize = true;
            this.Author5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(132)))), ((int)(((byte)(103)))));
            this.Author5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Author5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Author5.ForeColor = System.Drawing.Color.White;
            this.Author5.Location = new System.Drawing.Point(520, 419);
            this.Author5.Margin = new System.Windows.Forms.Padding(7, 6, 7, 6);
            this.Author5.Name = "Author5";
            this.Author5.Padding = new System.Windows.Forms.Padding(1);
            this.Author5.Size = new System.Drawing.Size(146, 52);
            this.Author5.TabIndex = 41;
            this.Author5.Text = "Неизвестный Автор";
            this.Author5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Test_choice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(234)))), ((int)(((byte)(210)))));
            this.ClientSize = new System.Drawing.Size(719, 562);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 1, 2, 1);
            this.Name = "Test_choice";
            this.Text = "Test_choice";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Test_choice_FormClosed);
            this.Load += new System.EventHandler(this.Test_choice_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Guna.UI2.WinForms.Guna2Button test_choise_1;
        private Guna.UI2.WinForms.Guna2Button test_choise_2;
        private Guna.UI2.WinForms.Guna2Button test_choise_3;
        private Guna.UI2.WinForms.Guna2Button test_choise_4;
        private Guna.UI2.WinForms.Guna2Button test_choise_5;
        private Guna.UI2.WinForms.Guna2Button test_page_back;
        private Guna.UI2.WinForms.Guna2Button test_page_next;
        private Guna.UI2.WinForms.Guna2Button test_choise_back_to_menu;
        private System.Windows.Forms.Label WnName;
        private System.Windows.Forms.Label TypeT1;
        private System.Windows.Forms.Label TypeT2;
        private System.Windows.Forms.Label TypeT3;
        private System.Windows.Forms.Label TypeT4;
        private System.Windows.Forms.Label TypeT5;
        private System.Windows.Forms.Label Author1;
        private System.Windows.Forms.Label Author2;
        private System.Windows.Forms.Label Author3;
        private System.Windows.Forms.Label Author4;
        private System.Windows.Forms.Label Author5;
    }
}